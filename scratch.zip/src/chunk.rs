use crate::{math::Face, ray::Ray3};
use glam::*;


// 64x64x64 chunk.
pub struct Chunk {
    cols: Box<[u64]>,
}

impl Chunk {
    pub fn new() -> Self {
        Self {
            cols: (0..4096).map(|_| 0u64).collect::<Box<_>>(),
        }
    }

    pub fn col_index(x: u32, z: u32) -> u32 {
        x | (z << 6)
    }

    pub fn get(&self, x: u32, y: u32, z: u32) -> bool {
        if (x | y | z) >= 64 {
            return false;
        }
        let index = Self::col_index(x, z);
        let col = self.cols[index as usize];
        (col & (1 << y)) != 0
    }

    pub fn set(&mut self, x: u32, y: u32, z: u32, on: bool) {
        if (x | y | z) >= 64 {
            return;
        }
        let index = Self::col_index(x, z);
        let mut col = self.cols[index as usize];
        if on {
            col = col | (1 << y);
        } else {
            col = col & !(1 << y);
        }
        self.cols[index as usize] = col;
    }

    pub fn fill_box(&mut self, start: (u32, u32, u32), end: (u32, u32, u32), on: bool) {
        let mask = (1u64 << end.1) - 1;
        let mask = mask & !((1 << start.1) - 1);
        if on {
            for z in start.2..end.2 {
                for x in start.0..end.0 {
                    let index = Self::col_index(x, z);
                    let col = self.cols[index as usize];
                    self.cols[index as usize] = col | mask;
                }
            }
        } else {
            let mask = !mask;
            for z in start.2..end.2 {
                for x in start.0..end.0 {
                    let index = Self::col_index(x, z);
                    let col = self.cols[index as usize];
                    self.cols[index as usize] = col & mask;
                }
            }
        }
    }

    pub fn set_with<F: Fn(bool) -> bool>(&mut self, x: u32, y: u32, z: u32, f: F) {
        let cur = self.get(x, y, z);
        let new = f(cur);
        self.set(x, y, z, new);
    }

    pub fn draw_box_with<F: Fn(bool) -> bool>(&mut self, start: (u32, u32, u32), end: (u32, u32, u32), f: F) {
        for y in start.1..end.1 {
            self.set_with(start.0, y, start.2, |b| f(b));
            self.set_with(end.0 - 1, y, start.2, |b| f(b));
            self.set_with(start.0, y, end.2 - 1, |b| f(b));
            self.set_with(end.0 - 1, y, end.2 - 1, |b| f(b));
        }
        for z in start.2+1..end.2-1 {
            self.set_with(start.0, start.1, z, |b| f(b));
            self.set_with(end.0-1, start.1, z, |b| f(b));
            self.set_with(start.0, end.1-1, z, |b| f(b));
            self.set_with(end.0-1, end.1-1, z, |b| f(b));
        }
        for x in start.0+1..end.0-1 {
            self.set_with(x, start.1, start.2, |b| f(b));
            self.set_with(x, end.1-1, start.2, |b| f(b));
            self.set_with(x, start.1, end.2-1, |b| f(b));
            self.set_with(x, end.1-1, end.2-1, |b| f(b));
        }
    }

    pub fn draw_box(&mut self, start: (u32, u32, u32), end: (u32, u32, u32), on: bool) {
        self.draw_box_with(start, end, |_| on);
    }

    pub fn raycast(&self, ray: Ray3, max_distance: f32) -> Option<RayHit> {
        let mut ray = ray;
        let (step, delta_min, delta_max, delta_add) = if ray.pos.x < 0.0 || ray.pos.y < 0.0 || ray.pos.z < 0.0
        || ray.pos.x >= 64.0 || ray.pos.y >= 64.0 || ray.pos.z >= 64.0 {
            // Calculate entry point (if there is one).
            // calculate distance to cross each plane
            let sign = ray.dir.signum();
            let step = sign.as_ivec3();
            let (dx_min, dx_max) = match step.x + 1 {
                0 => {
                    (
                        (ray.pos.x - 64.0) / -ray.dir.x,
                        ray.pos.x / -ray.dir.x,
                    )
                }
                1 => {
                    (<f32>::NEG_INFINITY, <f32>::INFINITY)
                }
                2 => {
                    (
                        -ray.pos.x / ray.dir.x,
                        (64.0 - ray.pos.x) / ray.dir.x,
                    )
                }
                _ => unreachable!(),
            };
            let (dy_min, dy_max) = match step.y + 1 {
                0 => {
                    (
                        (ray.pos.y - 64.0) / -ray.dir.y,
                        ray.pos.y / -ray.dir.y,
                    )
                }
                1 => {
                    (<f32>::NEG_INFINITY, <f32>::INFINITY)
                }
                2 => {
                    (
                        -ray.pos.y / ray.dir.y,
                        (64.0 - ray.pos.y) / ray.dir.y,
                    )
                }
                _ => unreachable!()
            };
            let (dz_min, dz_max) = match step.z + 1 {
                0 => {
                    (
                        (ray.pos.z - 64.0) / -ray.dir.z,
                        ray.pos.z / -ray.dir.z,
                    )
                }
                1 => {
                    (<f32>::NEG_INFINITY, <f32>::INFINITY)
                }
                2 => {
                    (
                        -ray.pos.z / ray.dir.z,
                        (64.0 - ray.pos.z) / ray.dir.z,
                    )
                }
                _ => unreachable!()
            };
            let max_min = dx_min.max(dy_min.max(dz_min));
            let min_max = dx_max.min(dy_max.min(dz_max));
            // Early return, the ray does not hit the volume.
            if max_min >= min_max {
                return None;
            }
            ray.pos = ray.pos + ray.dir * (max_min + 1e-5);
            (
                step,
                Some(vec3(dx_min, dy_min, dz_min)),
                vec3(dx_max, dy_max, dz_max),
                max_min,
            )
        } else {
            let sign = ray.dir.signum();
            let step = sign.as_ivec3();
            let dx_max = match step.x + 1 {
                0 => {
                    ray.pos.x / -ray.dir.x
                }
                1 => {
                    <f32>::INFINITY
                }
                2 => {
                    (64.0 - ray.pos.x) / ray.dir.x
                }
                _ => unreachable!()
            };
            let dy_max = match step.y + 1 {
                0 => {
                    ray.pos.y / -ray.dir.y
                }
                1 => {
                    <f32>::INFINITY
                }
                2 => {
                    (64.0 - ray.pos.y) / ray.dir.y
                }
                _ => unreachable!()
            };
            let dz_max = match step.z + 1{
                0 => {
                    ray.pos.z / -ray.dir.z
                }
                1 => {
                    <f32>::INFINITY
                }
                2 => {
                    (64.0 - ray.pos.z) / ray.dir.z
                }
                _ => unreachable!()
            };
            (
                step,
                None,
                vec3(dx_max, dy_max, dz_max),
                0.0,
            )
        };
        if delta_add >= max_distance {
            return None;
        }
        fn calc_delta(mag: f32) -> f32 {
            1.0 / mag.abs().max(<f32>::MIN_POSITIVE)
        }
        let delta = vec3(
            calc_delta(ray.dir.x),
            calc_delta(ray.dir.y),
            calc_delta(ray.dir.z),
        );

        let face = (
            if step.x >= 0 {
                Face::NegX
            } else {
                Face::PosX
            },
            if step.y >= 0 {
                Face::NegY
            } else {
                Face::PosY
            },
            if step.z >= 0 {
                Face::NegZ
            } else {
                Face::PosZ
            },
        );

        let fract = ray.pos.fract();

        fn calc_t_max(step: i32, fract: f32, mag: f32) -> f32 {
            if step > 0 {
                (1.0 - fract) / mag.abs().max(<f32>::MIN_POSITIVE)
            } else if step < 0 {
                fract / mag.abs().max(<f32>::MIN_POSITIVE)
            } else {
                <f32>::INFINITY
            }
        }
        let mut t_max = vec3(
            calc_t_max(step.x, fract.x, ray.dir.x) + delta_add,
            calc_t_max(step.y, fract.y, ray.dir.y) + delta_add,
            calc_t_max(step.z, fract.z, ray.dir.z) + delta_add,
        );

        let mut cell = ray.pos.floor().as_ivec3();
        let coord = (
            cell.x as u32,
            cell.y as u32,
            cell.z as u32,
        );
        if self.get(coord.0, coord.1, coord.2) {
            return Some(RayHit {
                face: delta_min.map(|min| {
                    if min.x >= min.y {
                        if min.x >= min.z {
                            face.0
                        } else {
                            face.2
                        }
                    } else {
                        if min.y >= min.z {
                            face.1
                        } else {
                            face.2
                        }
                    }
                }),
                coord: cell,
                distance: delta_add,
            });
        }
        loop {
            if t_max.x <= t_max.y {
                if t_max.x <= t_max.z {
                    if t_max.x >= delta_max.x || t_max.x >= max_distance {
                        return None;
                    }
                    cell.x += step.x;
                    let coord = (cell.x as u32, cell.y as u32, cell.z as u32);
                    if self.get(coord.0, coord.1, coord.2) {
                        return Some(RayHit::hit_face(face.0, cell, t_max.x));
                    }
                    t_max.x += delta.x;
                } else {
                    if t_max.z >= delta_max.z || t_max.z >= max_distance {
                        return None;
                    }
                    cell.z += step.z;
                    let coord = (cell.x as u32, cell.y as u32, cell.z as u32);
                    if self.get(coord.0, coord.1, coord.2) {
                        return Some(RayHit::hit_face(face.2, cell, t_max.z));
                    }
                    t_max.z += delta.z;
                }
            } else {
                if t_max.y <= t_max.z {
                    if t_max.y >= delta_max.y || t_max.y >= max_distance {
                        return None;
                    }
                    cell.y += step.y;
                    let coord = (cell.x as u32, cell.y as u32, cell.z as u32);
                    if self.get(coord.0, coord.1, coord.2) {
                        return Some(RayHit::hit_face(face.1, cell, t_max.y));
                    }
                    t_max.y += delta.y;
                } else {
                    if t_max.z >= delta_max.z || t_max.z >= max_distance {
                        return None;
                    }
                    cell.z += step.z;
                    let coord = (cell.x as u32, cell.y as u32, cell.z as u32);
                    if self.get(coord.0, coord.1, coord.2) {
                        return Some(RayHit::hit_face(face.2, cell, t_max.z));
                    }
                    t_max.z += delta.z;
                }
            }
        }
    }
}

pub struct RayHit {
    pub face: Option<Face>,
    pub coord: IVec3,
    pub distance: f32,
}

impl RayHit {
    pub fn hit_face(face: Face, coord: IVec3, distance: f32) -> Self {
        Self {
            face: Some(face),
            coord,
            distance,
        }
    }

    pub fn hit_cell(coord: IVec3, distance: f32) -> Self {
        Self {
            face: None,
            coord,
            distance,
        }
    }
}

#[test]
fn size_test() {
    println!("RayHit Size: {}", std::mem::size_of::<RayHit>());
    println!("Option<RayHit> Size: {}", std::mem::size_of::<Option<RayHit>>());
}

#[cfg(test)]
mod tests {
    use crate::tracegrid::GridSize;

    use super::*;
    #[test]
    fn next_pow2() {
        let size = GridSize::new(1920/2, 1080/2);
        let w = size.width.next_power_of_two() - size.width;
        let h = size.height.next_power_of_two() - size.height;
        if w <= h {
            println!("Width: {}\nNext Pow2: {}\nDifference: {}", size.width, size.width.next_power_of_two(), w);
        } else {
            println!("Height: {}\nNext Pow2: {}\nDifference: {}", size.height, size.height.next_power_of_two(), h);
        }
        let a = 1512;
        let b = 5125;
        println!("{}", (a | b) < 0);
    }
}