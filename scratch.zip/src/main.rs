#![allow(unused)]
use std::{borrow::Borrow, collections::{HashMap, VecDeque}, sync::{atomic::AtomicU64, Arc, Mutex}, time::{Duration, Instant}};

use image::{Rgb, RgbImage, Rgba, RgbaImage};
use itertools::Itertools;
use rand::{rngs::StdRng, Rng, SeedableRng};
use scratch::{chunk::{Chunk, RayHit}, dag::*, diff_plot::DiffPlot, open_simplex::open_simplex_2d, perlin::{make_seed, Permutation}, ray::Ray3, tracegrid::{GridSize, TraceGrid}};
use sha2::digest::typenum::Diff;

macro_rules! count_ids {
    () => { 0 };
    ($first:ident $(,$rest:ident)*$(,)?) => {
        (1 + count_ids!($($rest),*))
    };
}

// Goal:
// Have global registry of serializable types with IDs.

trait Fnord {
    fn foo(&self);
    fn bar(&self);
    fn baz(&self);
}

impl Fnord for i32 {
    fn foo(&self) {
        println!("i32::foo()");
    }

    fn bar(&self) {
        println!("i32::bar()");
    }

    fn baz(&self) {
        println!("i32::baz()");
    }
}

impl Fnord for &'static str {
    fn foo(&self) {
        println!("str::foo()");
    }

    fn bar(&self) {
        println!("str::bar()");
    }

    fn baz(&self) {
        println!("str::baz()");
    }
}

struct Fred {
    fnord: Box<dyn Fnord>,
}

impl Fred {
    pub fn new<T: Fnord + 'static>(value: T) -> Self {
        Self {
            fnord: Box::new(value),
        }
    }
}

impl std::ops::Deref for Fred {
    type Target = dyn Fnord;

    fn deref(&self) -> &Self::Target {
        self.fnord.as_ref()
    }
}

fn take_box<T: Into<Option<Box<u32>>>>(value: T) -> Option<Box<u32>> {
    value.into()
}

// fn expect<A, R: Try<Output>>(v: )

fn calculate_perf_tri() {
    let squares: [i64; 512] = std::array::from_fn(|i| (i as i64).pow(2));
    let squares_map: HashMap<i64, i64> = HashMap::from_iter(squares.iter().cloned().enumerate().map(|(i, sq)| { (sq, i as i64) }));
    for i in 1..512 {
        for j in 1..512 {
            let comb = squares[i] + squares[j];
            if let Some(&sq) = squares_map.get(&comb) {
                println!("{i} * {i} + {j} * {j} = {sq} * {sq}");
            }
        }
    }
}

macro_rules! doop {
    ($($name:lifetime : )? $block:block while $condition:expr) => {
        $($name :)?loop {
            $block
            if !($condition) {
                break $($name)?;
            }
        }
    };
}

fn plot_circle<F: FnMut(i32, i32)>(x: i32, y: i32, r: i32, mut f: F) {
    let mut px = -r;
    let mut py = 0;
    let mut err = 2-2*r;
    let mut r = r;
    doop!({
        f(x - px, y + py);
        f(x - py, y - px);
        f(x + px, y - py);
        f(x + py, y + px);
        r = err;
        if r <= py {
            py += 1;
            err += py * 2 + 1;
        }
        if r > px || err > py {
            px += 1;
            err += px * 2 + 1;
        }
    } while px < 0)
}

fn fill_circle<F: FnMut(i32, i32)>(x: i32, y: i32, r: i32, mut f: F) {
    let mut px = -r;
    let mut py = 0;
    let mut err = 2-2*r;
    let mut r = r;
    doop!({
        // f(x - px, y + py);
        // f(x + px, y - py);
        // f(x - py, y - px);
        // f(x + py, y + px);
        for i in (x + px)..=(x - px) {
            f(i, y + py);
            f(i, y - py);
        }
        r = err;
        if r <= py {
            py += 1;
            err += py * 2 + 1;
        }
        if r > px || err > py {
            px += 1;
            err += px * 2 + 1;
        }
    } while px < 0)
}

fn hor_line<F: FnMut(i32, i32)>(x_range: std::ops::Range<i32>, y: i32, mut f: F) {
    for x in x_range {
        f(x, y);
    }
}

// prototype!(
//     do!()
// );

fn gridsize_test() {
    let size = GridSize::new(2048, 2048);
    let mut indices = vec![(0u32, 0u32); (size.width*size.height) as usize];
    const ITERATIONS: usize = 1000;
    let mut timings = Vec::<Duration>::with_capacity(ITERATIONS);
    let mut work_proof = 0u32;
    for _ in 0..ITERATIONS {
        let start = Instant::now();
        for y in 0..size.height {
            for x in 0..size.width {
                let index = size.index(x, y);
                work_proof = work_proof.wrapping_add(index);
                indices[index as usize] = (x, y);
            }
        }
        work_proof = work_proof.wrapping_add(work_proof);
        let elapsed = start.elapsed();
        timings.push(elapsed);
    }
    println!("Work Proof: {work_proof}");
    let avg_count = timings.len() as u32;
    let avg_time = timings.into_iter().sum::<Duration>() / avg_count;
    println!("Iterations: {ITERATIONS}");
    println!("Average time: {avg_time:.3?}");
}

macro_rules! code_toggle {
    ($([$($kw:ident)?] {$($tokens:tt)*})*) => {
        $(
            code_toggle!{@unwrap; [$($kw)?] { $($tokens)* }}
        )*
    };
    (@unwrap; [r] {$($tokens:tt)*}) => {
        $($tokens)*
    };
    (@unwrap; [] {$($tokens:tt)*}) => {};

}

#[inline(always)]
pub const fn morton6(index: u32) -> u32 {
    let step1 = (index | (index << 6)) & 0b0000111000000111;
    let step2 = (step1 | (step1 << 2)) & 0b0011001000011001;
    let step3 = (step2 | (step2 << 2)) & 0b1001001001001001;
    return step3;
}

#[inline(always)]
pub fn fast_morton(index: u32, mask: u32) -> u32 {
    use std::arch::x86_64::_pdep_u32;
    unsafe {
        _pdep_u32(index, mask)
    }
}

#[inline(always)]
pub fn fast_morton6_3_x(index: u32) -> u32 {
    const SCATTER: u32 = 0b1001001001001001;
    fast_morton(index, SCATTER)
}

#[inline(always)]
pub fn fast_morton6_3_y(index: u32) -> u32 {
    const SCATTER: u32 = 0b10010010010010010;
    fast_morton(index, SCATTER)
}

#[inline(always)]
pub fn fast_morton6_3_z(index: u32) -> u32 {
    const SCATTER: u32 = 0b100100100100100100;
    fast_morton(index, SCATTER)
}

#[inline(always)]
pub fn morton6_3(x: u32, y: u32, z: u32) -> u32 {
    fast_morton6_3_x(x) | fast_morton6_3_y(y) | fast_morton6_3_z(z)
}

pub struct RaytraceChunk {
    blocks: Box<[u32]>,
}

impl RaytraceChunk {
    pub fn new() -> Self {
        Self {
            blocks: (0..64*64*64).map(|_| 0u32).collect(),
        }
    }

    pub fn get(&self, x: i32, y: i32, z: i32) -> u32 {
        let x = x as u32 & 0b111111;
        let y = y as u32 & 0b111111;
        let z = z as u32 & 0b111111;

        let index = ((y << 12) | (z << 6) | x) as usize;
        self.blocks[index]
    }

    pub fn get_morton(&self, x: i32, y: i32, z: i32) -> u32 {
        let index = morton6_3(x as u32, y as u32, z as u32);
        self.blocks[index as usize]
    }

    pub fn set(&mut self, x: i32, y: i32, z: i32, id: u32) {
        let x = x as u32 & 0b111111;
        let y = y as u32 & 0b111111;
        let z = z as u32 & 0b111111;

        let index = ((y << 12) | (z << 6) | x) as usize;
        self.blocks[index] = id;
    }

    pub fn set_morton(&mut self, x: i32, y: i32, z: i32, id: u32) {
        let index = morton6_3(x as u32, y as u32, z as u32);
        self.blocks[index as usize] = id;
    }
}

macro_rules! timeit {
    ($($tokens:tt)*) => {
        {
            let timeit_start = Instant::now();
            $($tokens)*
            timeit_start.elapsed()
        }
    };
}

fn main() {
    // gridsize_test();
    code_toggle!(
        [] {
            gridsize_test();
        }
        [r] {
            let start = Instant::now();
            raycast_scene();
            let elapsed = start.elapsed();
            println!("Program finished in {elapsed:.3?}");
        }
        [] {
            morton_test();
        }
    );
    return;
}

macro_rules! timed {
    ($fmt:literal => $code:expr) => {
        let elapsed_time = timeit!{
            $code;
        };
        println!($fmt, time=elapsed_time);
    };
}

pub fn morton_test() {
    let mut chunk = RaytraceChunk::new();
    // let elapsed = timeit!{
        // };
        // println!("Set Morton: {elapsed:.3?}");
    timed!("Set: {time:.3?}" => {
        for x in 0..64 {
            for y in 0..64 {
                for z in 0..64 {
                    chunk.set(x, y, z, x as u32);
                }
            }
        }
    });
    let mut total = 0;
    timed!("Get: {time:.3?}" => {
        for x in 0..64 {
            for y in 0..64 {
                for z in 0..64 {
                    let id = chunk.get(x, y, z);
                    total += id;
                }
            }
        }
    });
    println!("Proof of work: {total}");
}

pub fn raycast_scene() {
    use glam::*;
    use scratch::math::*;
    use scratch::camera::*;
    use scratch::perlin::perlin;
    use rayon::prelude::*;
    println!("Starting.");
    let perm = Permutation::from_seed(make_seed(1243));
    // let size = GridSize::new(1280, 720);
    let size = GridSize::new(1920*4, 1080*4);
    // let same = 1024*16;
    // let size = GridSize::new(same, same/2);
    let mut cam = Camera::from_look_at(vec3(100.0, 70.0, -64.0), vec3(32., 8., 32.), 90.0f32.to_radians(), 1.0, 100.0, (size.width, size.height));

    let mut last = IVec3::ZERO;
    let mut chunk = Chunk::new();
    fn checkerboard(x: u32, y: u32, z: u32) -> bool {
        ((x & 1) ^ (y & 1) ^ (z & 1)) != 0
    }
    let start = Instant::now();
    let rays = (0..size.width*size.height).into_par_iter().map(|i| {
        let (x, y) = size.inv_index(i);
        let screen_pos = vec2(x as f32 / size.width as f32 - 0.5, y as f32 / size.height as f32 - 0.5);
        cam.normalized_screen_to_ray(screen_pos)
    }).collect::<Vec<_>>();
    let elapsed = start.elapsed();
    println!("Calculated {} rays in {elapsed:.3?}", rays.len());

    // for x in 0..64 {
    //     for z in 0..64 {
    //         for y in 0..64 {
    //             chunk.set(x, y, z, checkerboard(x, y, z));
    //         }
    //     }
    // }

    let start = Instant::now();
    for x in 0..64 {
        for z in 0..64 {
            let min_dist = x.min(z).min(63-x).min(63-z);
            let falloff = (min_dist as f32) / 32.0;
            let height = (perlin(&perm, x as f32 / 64.0, z as f32 / 64.0) * 0.5) + 0.5;
            let h = ((height * 64.0 * falloff) as u32).max(1);
            chunk.fill_box((x, 0, z), (x+1, h, z+1), true);
        }
    }
    let elapsed = start.elapsed();
    println!("Generated terrain in {elapsed:.3?}");

    // for x in 0i32..64 {
    //     for y in 0i32..64 {
    //         for z in 0i32..64 {
    //             let ox = (32 - x).abs();
    //             let oy = (32 - y).abs();
    //             let oz = (32 - z).abs();
    //             let ods = ((ox + 7) * (ox + 7)) + ((oy + 7) * (oy + 7)) + oz * oz;
    //             if ods <= DS {
    //                 chunk.set(x as u32, y as u32, z as u32, true);
    //             }
    //             // let mut c = 0;
    //             // if x % 8 == 0 {
    //             //     c += 1;
    //             // }
    //             // if y % 8 == 0 {
    //             //     c += 1;
    //             // }
    //             // if z % 8 == 0 {
    //             //     c += 1;
    //             // }
    //             // if c > 1 {
    //             //     chunk.set(x, y, z, true);
    //             // }
    //         }
    //     }
    // }

    // for x in 0..64 {
    //     for y in 0..64 {
    //         for z in 0..64 {
    //             chunk.set(x, y, z, true);
    //         }
    //     }
    // }
    // let line_width = 4;
    // chunk.fill_box((16, 16, 16), (48, 48, 48), true);
    // chunk.fill_box((16, 16 + line_width, 16 + line_width), (48, 48 - line_width, 48 - line_width), false);
    // chunk.fill_box((16 + line_width, 16, 16 + line_width), (48 - line_width, 48, 48 - line_width), false);
    // chunk.fill_box((16 + line_width, 16 + line_width, 16), (48 - line_width, 48 - line_width, 48), false);

    // chunk.draw_box((16, 16, 16), (48, 48, 48), true);
    // chunk.draw_box((20, 20, 20), (44, 44, 44), true);
    // chunk.draw_box((24, 24, 24), (40, 40, 40), true);
    // chunk.draw_box((28, 28, 28), (36, 36, 36), true);
    // 10202010102020101020201
    fn box_at(start: (u32, u32, u32)) -> std::ops::Range<(u32, u32, u32)> {
        start..(start.0 + 6, start.1 + 6, start.2 + 6)
    }
    fn next_start(end: (u32, u32, u32)) -> (u32, u32, u32) {
        (end.0 - 3, end.1 - 3, end.2 - 3)
    }
    let start = Instant::now();
    let mut r = box_at((0, 0, 0));
    while r.end.0 <= 64 {
        chunk.draw_box(r.start, r.end, true);
        r = box_at(next_start(r.end));
    }
    let elapsed = start.elapsed();
    println!("Placed blocks in {elapsed:.3?}");

    // for x in 0..64 {
    //     for z in 0..64 {
    //         for y in 0..64 {
    //             let b = chunk.get(x, y, z);
    //             let cb1 = checkerboard(x, y, z);
    //             let cb2 = checkerboard(x/2, y/2, z/2);
    //             let cb3 = checkerboard(x/4, y/4, z/4) || true;
    //             chunk.set(x, y, z, b && cb1 && cb2 && cb3);
    //         }
    //     }
    // }


    // let mut plot = DiffPlot::new(1024, 1024);
    
    let mut img = RgbImage::new(size.width, size.height);

    let near = 0.1;
    let far = 250.0;
    let depth_mul = 1.0 / (far - near);
    // let mut grid = (0..size.width*size.height).map(|_| Option::<RayHit>::None).collect::<Vec<_>>();
    let start = std::time::Instant::now();
    {
        let chunk = &chunk;
        let rays = rays.as_slice();
        img.par_pixels_mut().enumerate().for_each(move |(i, pixel)| {
            // let (x, y) = size.inv_index(i as u32);
            // let screen_pos = vec2(x as f32 / size.width as f32 - 0.5, y as f32 / size.height as f32 - 0.5);
            // let ray = cam.normalized_screen_to_ray(screen_pos);
            let ray = rays[i];
            let Some(hit) = chunk.raycast(ray, far) else {
                return;
            };
            if hit.distance < near {
                return;
            }
            let dnorm = (hit.distance - near) * depth_mul;
            let pix = (dnorm * 255.0) as u8;
            let rgb = match hit.face.map(|face| face.axis()) {
                Some(Axis::X) => Rgb([pix, 0, 0]),
                Some(Axis::Y) => Rgb([0, pix, 0]),
                Some(Axis::Z) => Rgb([0, 0, pix]),
                _ => Rgb([255, 255, 255]),
            };
            *pixel = rgb;
        });
    }
    let elapsed = start.elapsed();
    println!("Rendered {size} image in {elapsed:.3?}");

    // for y in 0..1024 {
    //     for x in 0..1024 {
    //         if plot.get(x, y) {
    //             img.put_pixel(x, y, Rgb([255, 255, 255]));
    //         } else {
    //             img.put_pixel(x, y, Rgb([0, 0, 0]));
    //         }
    //     }
    // }

    img.save("raycast.png").expect("Failed to save image.");
}

macro_rules! grave {($($_:tt)*) => {};}

grave!{
    fn in_bounds(x: i32, y: i32) -> bool {
        x >= 0 && y >= 0 && x < 1024 && y < 1024
    }

    fn pix(step_count: i32, level: i32) -> Rgb<u8> {
        let level = level as f32;
        let t = level / step_count as f32;
        let gray = (255.0 * t) as u8;
        Rgb([gray; 3])
    }

    struct Algo {
        rng: StdRng,
        plot: DiffPlot,
        img: RgbImage,
        step_count: i32,
        queue: VecDeque<(i32, i32, i32)>,
    }

    let mut algo = Algo {
        rng: StdRng::from_seed(make_seed(13512512)),
        plot: DiffPlot::new(1024, 1024),
        img: RgbImage::new(1024, 1024),
        step_count: 20,
        queue: VecDeque::from([(512, 512, 20)]),
    };

    const DISP_R: &[i32] = &[0, 1, 3, 5, 7, 11, -1, -3, -5, -7, -11];

    fn algo_step(algo: &mut Algo, x: i32, y: i32, step: i32) {
        if !in_bounds(x, y) {
            return;
        }
        let disp_r: usize = algo.rng.random_range(0..DISP_R.len());
        let disp_r = DISP_R[disp_r];
        plot_circle(x, y, 12 + disp_r, |x, y| {
            if !in_bounds(x, y) {
                return;
            }
            if algo.plot.set(x as u32, y as u32, true) {
                return;
            }
            algo.img.put_pixel(x as u32, y as u32, pix(algo.step_count, step));
            if step != 0 {
                algo.queue.push_back((x, y, step - 1));
            }
        });
        fill_circle(x, y, 12 + disp_r, |x, y| {
            if !in_bounds(x, y) {
                return;
            }
            if algo.plot.set(x as u32, y as u32, true) {
                return;
            }
            algo.img.put_pixel(x as u32, y as u32, pix(algo.step_count, step));
        });
    }
    while let Some((x, y, step)) = algo.queue.pop_front() {
        println!("{step} {:?}", pix(10, step));
        algo_step(&mut algo, x, y, step);
    }

    // fill_circle(128, 128, 16, |x, y| {
    //     if x < 0 || y < 0 || x >= 256 || y >= 256 {
    //         return;
    //     }
    //     let x = x as u32;
    //     let y = y as u32;
    //     // img.put_pixel(x, y, Rgb([255, 0, 0]));
    // });
    // plot_circle(128, 128, 16, |x, y| {
    //     if x < 0 || y < 0 || x >= 256 || y >= 256 {
    //         return;
    //     }
    //     let x = x as u32;
    //     let y = y as u32;
    //     // img.put_pixel(x, y, Rgb([0, 255, 0]));
    // });
    algo.img.save("output.png").expect("Failed to save image.");
}

grave!{
    fn branch_experiment() {
        pub struct Branch<I, F, T, R> {
            false_: F,
            true_: T,
            _phantom: std::marker::PhantomData<(I, R)>
        }
        
        impl<I, F, T, R> Branch<I, F, T, R>
        where
            F: FnMut(I) -> R,
            T: FnMut(I) -> R,
        {
            pub const fn new(false_: F, true_: T) -> Self {
                Self {
                    false_,
                    true_,
                    _phantom: std::marker::PhantomData,
                }
            }
        
            pub fn branch(&mut self, branch: bool, input: I) -> R {
                match branch 
                {
                    false => (self.false_)(input),
                    true => (self.true_)(input),
                }
            }
        }
        
        let mut branch = Branch::new(
            |i: i32| i - 1,
            |i: i32| i + 1,
        );
        println!("{}", branch.branch(false, 3));
        println!("{}", branch.branch(true, 3));
    }
}

macro_rules! prototype { ($($_:tt)*) => {} }

prototype!(
    struct Foo {
        name: &'static str,
    }

    impl Foo {
        pub fn new(name: &'static str) -> Self {
            Self {
                name,
            }
        }
        
        pub macro bar(self) {
            () => {};
            ($($name:ident),*) => {
                $(
                    self.$name();
                )*
            };
        }
        
        fn fnord(&self) {
            println!("fnord({})", self.name);
        }
        
        fn fred(&self) {
            println!("fred({})", self.name);
        }
        
        fn baz(&self) {
            println!("baz({})", self.name);
        }
    }
    
    
    
    fn main() {
        let foo = Foo::new("Doobie");
        foo.bar(fnord, fred, baz);
    }
);
